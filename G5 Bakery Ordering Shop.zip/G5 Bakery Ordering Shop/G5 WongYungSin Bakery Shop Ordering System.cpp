#include<iostream>     
#include<fstream>
#include<windows.h>   //colour
#include<sstream>  
#include<string>   
#include<cstdlib>    //atoi and atof 
#include<iomanip>
#include<vector>     //vector
#include<ctime>      //time
#include<conio.h>    //getch()
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

//picture
#define WIDTH 115
#define HEIGHT 31

//clear screen function
void clrSr()     
{ 
  #ifdef _WIN32
    system("cls");
  #else
    system("clear");
  #endif
}

//set the color of the text and background
void setColor(int textColor, int bgColor)
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, (bgColor << 4) | textColor);
}

void handleInputError() 
{   
    cin.clear(); 
    cin.ignore(); 
    setColor(12,0);
    cout << "\nWrong input! Please enter again..." << endl;
}

//Class for view_product(...) function
class product {
	public:
		 int id;
         string name;
         string category;
         double price;
         int stock;
};

//Class for order(...) function 
class OrderRecord {
	public:
      int id;
      int qty;
      string name1;
      double price;
      
      void addQuantity(int quantity) 
	  { qty += quantity;
      }

      void removeQuantity(int quantity) 
	  { if (quantity <= qty)
        qty -= quantity;
      }
};


//homepage
void homepage(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp);
//login
string get_hidden_password(); 
void forgot_password(vector<product>& menu, string& wayName, int& quantity, const time_t& timestamp);
string login_page(vector<product>& menu, string& wayName, int& quantity, const time_t& timestamp);
//menu
void store_product(vector<product>& menu);
void view_product(vector<product>& menu);
//checkout
void checkout(const double& subtotal, time_t& timestamp, string& wayName, const string& name, const int& recordCount, OrderRecord* record, int& quantity, vector<product>& menu);
//order
string asking();
void addOrder(int& ans, OrderRecord* record, int& recordCount, vector<product>& menu, double& totalprice, int& checkQuantity, int& ordernum, int& quantity);
void removeOrder(int& recordCount, OrderRecord* record, vector<product>& menu, double& totalprice, int& checkQuantity, const string& name, string& wayName, int& quantity, const time_t& timestamp, const int& removeId, int& rvqty);
void cart(double& totalprice, int& recordCount, OrderRecord* record, string& wayName, const string& name, vector<product>& menu);
void ProceedToCheckOut(vector<product>& menu, const string& name, string& wayName, double& totalprice, time_t& timestamp, int& recordCount, OrderRecord* record, int& quantity);
void editCart(double& totalprice, int& recordCount, OrderRecord* record, vector<product>& menu, int& checkQuantity, string& name, string& wayName, int& ans, int& ordernum, int& quantity, time_t timestamp, int& removeId, int& rvqty);
void order(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp);  
//check order history
void check_history(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp);
void askDateFilter(time_t& startDate, time_t& endDate);
//picture for ending
void pic_thanks(); 

// 1.Login
string current_user = "";
bool is_logged_in = false;

string get_hidden_password() 
{
    string password = "";
    char ch;
    while ((ch = _getch()) != '\r')
	{
        if (ch == '\b') 
		{
            if (!password.empty()) 
			{
                cout << "\b \b";
                password.erase(password.size() - 1);
            } 
        } 
		else 
		{
            password += ch;
            cout << '*';
        }
    }
    cout << endl;
    return password;
}

void forgot_password(vector<product>& menu, string& wayName, int& quantity, const time_t& timestamp) 
{
    string user, pass;
    bool match = false;

    cout << "\nEnter your username to reset your password: ";
    getline(cin, user);  

    ifstream read("users.txt");
    ofstream temp("temp.txt");
    string stored_user, stored_pass;

    while (read >> stored_user >> stored_pass) 
	{
        if (stored_user == user) 
		{
            cout << "User found. Enter new password: ";
            pass = get_hidden_password();
            temp << stored_user << " " << pass << endl;
            match = true;
        } 
		else 
		{
            temp << stored_user << " " << stored_pass << endl;
        }
    }
    read.close();
    temp.close();

    remove("users.txt");
    rename("temp.txt", "users.txt");

    if (match)
        cout << "\nPassword successfully updated.\n";
    else
        cout << "\nUsername not found.\n";

    login_page(menu, wayName, quantity, timestamp);
}

string login_page(vector<product>& menu, string& wayName, int& quantity, const time_t& timestamp) 
{
    while (true) {
        int choice;
        cout << "\n=== Welcome to Dora's Oven ===\n";
        cout << "1. Sign In\n2. Log In\n3. Forgot Password\nEnter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string name, password;
            cout << "Enter your name: ";
            getline(cin, name);
            cout << "Create a password: ";
            password = get_hidden_password();

            ofstream fout("users.txt", ios::app);
            fout << name << " " << password << endl;
            fout.close();

            cout << "\nSign in successful. You can now log in.\n";

        } else if (choice == 2) {
            string name, password, file_name, file_pass;
            cout << "Enter your name: ";
            getline(cin, name);
            cout << "Enter your password: ";
            password = get_hidden_password();

            bool found = false;
            ifstream fin("users.txt");
            while (fin >> file_name >> file_pass) {
                if (file_name == name && file_pass == password) {
                    found = true;
                    break;
                }
            }
            fin.close();

            if (found) {
                is_logged_in = true;
                current_user = name;
                setColor(14, 0);
                cout << "\nLogin successful. Welcome back, " << name << "!\n";
                cin.ignore(); 
                homepage(menu, name, wayName, quantity, timestamp);
                return name;
            } else {
                cout << "\nLogin failed. Please try again.\n";
            }

        } else if (choice == 3) {
            forgot_password(menu, wayName, quantity, timestamp);
        } else {
            cout << "\nInvalid choice. Please try again.\n";
        }
    }
}

// 2.Menu
void store_product(vector<product>& menu)    
{
	menu.clear();
    ifstream read("product list.txt");

    if (!read.is_open()) 
	{
        cout << "Sorry..something went wrong...Please try again." << endl;
        return; 
    }
    //Store the data from the read file    
    string list;                  
    while (getline(read, list)) 
	{
        stringstream ss(list);
        string id_str, name, category, price_str, stock_str;

        getline(ss, id_str, ',');
        getline(ss, name, ',');
        getline(ss, category, ',');
        getline(ss, price_str, ',');
        getline(ss, stock_str, ',');

        product p;
        p.id = atoi(id_str.c_str());           
        p.name = name;
        p.category = category;
        p.price = atof(price_str.c_str());     
        p.stock = atoi(stock_str.c_str());     
        menu.push_back(p);
    }
       read.close();
}

void view_product(vector<product>& menu) 
{
    //set color
    setColor(14, 0);  //(light yellow text,black bg)
    //Title
    store_product(menu);
    setColor(6, 0);//(yellow text,black bg)

    cout << "ID   "
        << "Name                    "
        << "Category      "
        << "Price  "
        << "Stock  " << endl;

    //divider
    cout << "------------------------------------------------------" << endl;
    
    //Display data  
    for (int i = 0; i < menu.size(); i++) 
	{   cout << left << setw(5) << menu[i].id
             << left << setw(25) << menu[i].name
             << left << setw(10) << menu[i].category
             << right << setw(7) << fixed << setprecision(2) << menu[i].price
             << right << setw(7) << menu[i].stock << endl;
    }
    //Return to normal color
    setColor(7, 0);
}

// 3.HomePage
void homepage(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp)  
{
	   clrSr();
	   setColor(10,0);
       cout<<"******************************************************************************"<<endl;
       setColor(7,0);
       cout<<":                                                                            :"<<endl;
	   cout<<":                         ~ Dora Oven Bakery Shop ~                          :"<<endl;
	   setColor(9,0);
	   cout<<":                          -----------------------                           :"<<endl;
	   cout<<":                                                                            :"<<endl;
	   cout<<"******************************************************************************"<<endl; 
       setColor(11,0);
       cout<<"\n\n  *What can I serve for you* ?                       ~~~~~~~~~~~~~~~~~~~~~~"<<endl;
       setColor(9,0);
       cout<<"\n  (s) Start New Order                                 :   Our Signature  : "<<endl;                
       cout<<"  (c) Check Order History                             : < Anywhere Bun > : "<<endl;
       setColor(11,0);
       cout<<"  (e) Exit\n                                                     ~~~~~~~~~~~~~~~~~~~~~~"<<endl;
       cout<<"  (o) Log out"<<endl;
       setColor(14,0);
       cout<<"                                                       Remember to smile  "<<endl;
       setColor(9,0);
	   cout<<"                                                           Everyday ^-^   "<<endl;
	   setColor(7,0);
	   cout<<"\n\n\nLet's enjoy some pastries and find your happiness !"<<endl;

        char choice;
        while(true)
        {
          setColor(10,0);
          cout<<"\nPlease enter your choice [ s | c | e | o ]: ";
          cin >> choice;

          if(choice == 'S' || choice == 's') 
		  {
            clrSr();  
            string asking();
            order(menu, name, wayName, quantity, timestamp); 
            return;
          }
          else if(choice == 'C' || choice == 'c') 
          {
        	clrSr();
        	check_history(menu, name, wayName, quantity, timestamp);
        	return;
		  }
          else if(choice == 'E' || choice == 'e') 
		  {
		  	clrSr();
		  	setColor(14,0);
            cout <<"Thank you for visiting. Goodbye!\n";
            return;  
          }
          else if(choice == 'O' || choice == 'o')
          { 
		    clrSr();
		    setColor(7,0);
            login_page(menu, wayName, quantity, timestamp);
		  }
          else 
		  {
		  	setColor(12,0);
            cout <<"Invalid choice. Please try again.\n";
          }
        }
       setColor(7,0);
} 

// 4.CheckOut
void checkout(const double& subtotal, time_t& timestamp, string& wayName, const string& name, const int& recordCount, OrderRecord* record, int& quantity, vector<product>& menu)
{
	string deliveryAddress = "", orderNo;
	
    setColor(14, 0);
    if(wayName == "delivery") 
	{   
        cout << "\nPlease enter your delivery address: ";
        cin.ignore();
        getline(cin, deliveryAddress);
        
        cout<<"\nWe will deliver your order soon!"<<endl;
    }
    
    if(wayName == "pickup") 
    {   cout<<"You should pick up your order before 8pm by today."<<endl;
    }

    cout<<"\n\n..................Press enter to view your receipt...................."<<endl;
	cin.ignore();
	cin.get(); 
	clrSr();
	
    time_t now = time(0);
    timestamp = now;
    struct tm* timeinfo = localtime(&timestamp); 
    stringstream ss;
    
    ss << 1900 + timeinfo->tm_year
       << std::setw(2) << std::setfill('0') << 1 + timeinfo->tm_mon  // month
       << std::setw(2) << std::setfill('0') << timeinfo->tm_mday     // day
       << std::setw(2) << std::setfill('0') << timeinfo->tm_hour     // hour
       << std::setw(2) << std::setfill('0') << timeinfo->tm_min      // min
       << std::setw(2) << std::setfill('0') << timeinfo->tm_sec;     // sec

    orderNo = ss.str();
    
    // print out the receipt
    cout << "\n---------------------------------------------\n";
    //display color
    setColor(0, 14);//(blue text,white bg)
    cout << string(45, ' ') << endl;
    cout << setw(45) << left << "         Dora's Oven Bakery Receipt        " << endl;
    cout << string(45, ' ') << endl;

    //Return to normal color
    setColor(14, 0);
    cout << "---------------------------------------------\n";
    cout << "Order No     : " << orderNo << endl;
    cout << "Customer     : " << name << endl;
    cout << "Order Date   : " << ctime(&timestamp); 
	cout << "Order Type   : " << wayName << endl; 
    for (int dis = 0; dis < recordCount; dis++) 
	cout << record[dis].qty << "x  " << record[dis].id <<"  "<< record[dis].name1 <<"  RM "<< record[dis].price <<endl;
    cout << "---------------------------------------------\n";
    cout << "Subtotal     : RM " << fixed << setprecision(2) << subtotal << endl;
    cout << "Tax (0.20)   : RM 0.20\n";
    cout << "Packaging Fee: RM 0.50\n";
    double total = subtotal + 0.20 + 0.50;
    cout << "Total        : RM " << fixed << setprecision(2) << total << endl;
    cout << "---------------------------------------------\n";
    cout << "Thank you for your order!\n\n";
    
    // Save to history file
    ofstream historyFile("order_history.txt", ios::app);
    if (historyFile.is_open()) 
	{   historyFile << "OrderNo:" << orderNo << "\n";
        historyFile << "Customer:" << name << "\n";
        historyFile << "Date:" << timestamp << "\n";
        historyFile << "Type:" << wayName << "\n";
        if (wayName == "delivery" && !deliveryAddress.empty()) 
		{  historyFile << "Address:" << deliveryAddress << "\n";
        }
        historyFile << "Subtotal:" << fixed << setprecision(2) << subtotal << "\n";
        historyFile << "Total:" << fixed << setprecision(2) << total << "\n";
        historyFile << "Items:" << recordCount << "\n";
        
        for (int i = 0; i < recordCount; i++) 
		{  historyFile << record[i].id << "," << record[i].name1 << ","
                       << fixed << setprecision(2) << record[i].price << ","
                       << record[i].qty << "\n";
        }
        
        historyFile << "---END---\n";
        historyFile.close();
    }
    
    cout<<"\n\n\nPress enter to return to homepage...";
    cin.ignore();
    clrSr();
    pic_thanks();
    clrSr();
    homepage(menu, name, wayName, quantity, timestamp);
    
    //Return to normal color
    setColor(7, 0);
}

// 5.Order
string asking()  
{
    char way;
    string wayName;
    bool wayFound = false;
    
    setColor(14,0);
    cout<<"\n--(P) Pick up \n--(D) Delivery"<<endl;
    while(!wayFound)
    {
      setColor(14,0);
      cout<<"\nEnter [P/D] : ";
      cin>>way;
      if(way == 'P' || way == 'p')
      { wayName = "pickup";             //store wayName for use by the checkout(...) function
        wayFound = true;
      }
      else if(way == 'D' || way == 'd')
	  { wayName = "delivery";    
	    wayFound = true;
      }
      else
      { setColor(12,0); 
	    cout<<"\nWrong enter ! Please enter again..."<<endl;
      }
    }
	
	cout<<"\n\nWell, you can start order now !"<<endl;
	cout<<"Press enter to continue"<<endl;
	setColor(7, 0);
	
	cin.ignore();
	cin.get();
	clrSr();
	
	return wayName;
}

void addOrder(int& ans, OrderRecord* record, int& recordCount, vector<product>& menu, double& totalprice, int& checkQuantity, int& ordernum, int& quantity)
{
    if(quantity <= 0) 
	{   setColor(12,0); 
        cout<<"Quantity must be at least 1. Please enter again"<< endl;
        return;
    }

    bool found2 = false;
    for(int j = 0; j < menu.size(); j++) 
    {
        if(menu[j].id == ans)
        {
            found2 = true;
            if(menu[j].stock < quantity) 
			{   setColor(5,0);
                cout<<"Sorry, only "<< menu[j].stock <<" left in stock.\n";
                return;
            }
 
            bool exists = false;
            for(int k = 0; k < recordCount; k++) 
            {
                if(record[k].id == ans)    //if the product has been added before will run this loop
                {
                    record[k].addQuantity(quantity);            //function member //add the quantity
                    menu[j].stock -= quantity;                  //subtract the product stock quantity
                    totalprice += record[k].price * quantity;   //calculate subtotal
                    checkQuantity += quantity;                  //add the total order quantity
                    setColor(10,0);
                    cout<<"Added to cart successfully!"<< endl;
                    exists = true;
                    break;
                }
            }

            if(!exists)    //if the product has not been added yet will run this loop
            {
                record[recordCount].id = ans;    
                record[recordCount].qty = quantity;
                record[recordCount].name1 = menu[j].name;
                record[recordCount].price = menu[j].price;
                recordCount++;
                menu[j].stock -= quantity;
                totalprice += menu[j].price * quantity;
                checkQuantity += quantity;
                setColor(10,0);
                cout<<"Added to cart successfully! Order number : "<< ordernum << endl;
                ordernum += 1;
            }
            break;
        }
    }
    setColor(12,0);
    if(!found2)
      cout<<"Invalid product ID. Please enter again.\n";
      
    setColor(7,0);
}

void removeOrder(int& recordCount, OrderRecord* record, vector<product>& menu, double& totalprice, int& checkQuantity, const string& name, string& wayName, int& quantity, const time_t& timestamp, const int& removeId, int& rvqty)
{                                                                                
    bool found;

    for(int i = 0; i < recordCount; i++)  
    {
        if(record[i].id == removeId)  
        {  
            found = true;
            while(rvqty > record[i].qty || rvqty <= 0) 
            {   
			    setColor(5,0);
                cout<<"Sorry, you can only remove "<< record[i].qty<< " item."<<endl;
                return; 
            }    

            for(int j = 0; j < menu.size(); j++)
            {
                if(menu[j].id == removeId) 
                {
                    menu[j].stock += rvqty;                  //add back product stock quantity
                    totalprice -= record[i].price * rvqty;   //subtract the subtotol
                    break;
                }
            }

            if(rvqty == record[i].qty) 
            {
                for(int k = i; k < recordCount - 1; k++)   
                {   
                    record[k] = record[k + 1];   //delete an order
                }
                recordCount--;
            }
            else
            {
                record[i].removeQuantity(rvqty);  //function member//subtract the quantity
            }

            checkQuantity -= rvqty;  //subtract the total order quantity 

            if(checkQuantity == 0)
            {   setColor(5,0);
                cout<<"\nSorry, your order is now empty"<< endl;
                cout<<"Press enter to go back to the main menu"<< endl;
                cin.ignore();
                cin.get();
                clrSr();
                homepage(menu, name, wayName, quantity, timestamp);
                return;
            }
            setColor(10,0);
            cout<<"Successfully removed from your order.\n";
            break;
        }  
    } 
    setColor(12,0);
    if(!found) 
      cout<<"\nSorry, not found in your order.\n"; 
      
    setColor(7,0);
}

void cart(double& totalprice, int& recordCount, OrderRecord* record, string& wayName, const string& name, vector<product>& menu)
{
    const double tax = 0.20, container = 0.50;
    double Total = 0.0;  //Total == subtotal add with any other fees
    time_t timestamp;    //order time
    time(&timestamp);
    
    //display order cart    
        setColor(10, 0);
        cout<<"\n------------------------------------"<< endl;
        cout<<"       <     Your Cart     >       "<<endl;
        cout<<"\nOrder time : "<< ctime(&timestamp) <<endl;
        cout<<"\nOrder list : "<<endl;
        for (int dis = 0; dis < recordCount; dis++)
        { cout<<"\n"<< record[dis].qty <<"x  "<< record[dis].id <<"  "<< record[dis].name1 <<endl;
          cout<<"RM "<< record[dis].price <<" x "<< record[dis].qty <<" = "<< record[dis].price * record[dis].qty <<endl;
        }
        cout<<"\n\nOrder price"<<endl;
        cout<<"Sub Total       : RM "<< fixed << setprecision(2) << totalprice <<endl;
        cout<<"Service Tax     : RM "<< tax <<endl;
        cout<<"Packaging Fee   : RM "<< container <<endl;
        Total = totalprice + tax + container;
        cout<<"Your Total      : RM "<< fixed << setprecision(2) << Total <<endl;
        cout<<"\n------------------------------------"<< endl; 
        setColor(7,0);
}

void ProceedToCheckOut(vector<product>& menu, const string& name, string& wayName, double& totalprice, time_t& timestamp, int& recordCount, OrderRecord* record, int& quantity)
{
    char ans4;
    while (true)
    {
        setColor(14, 0);
        cout<<"\n\n\nProceed to check out?"<<endl;
        cout<<"(Y) Yes\n(N) No, return to main menu"<<endl;
        cout<<"\nEnter [Y/N] : ";
        cin >> ans4;

        if(ans4 == 'y' || ans4 == 'Y')
        {
            setColor(7, 0);
            clrSr();
            checkout(totalprice, timestamp, wayName, name, recordCount, record, quantity, menu);  
            return;
        }
        else if(ans4 == 'n' || ans4 == 'N')
        {
            setColor(7, 0);
            clrSr();
            homepage(menu, name, wayName, quantity, timestamp);
            return;
        }
        else
        {
            setColor(12, 0);
            cout<<"\nWrong enter ! Please enter again..."<<endl;
        }
    }
}

void editCart(double& totalprice, int& recordCount, OrderRecord* record, vector<product>& menu, int& checkQuantity, const string& name, string& wayName, int& ans, int& ordernum, int& quantity, time_t timestamp, int& removeId, int& rvqty)
{
	char ans5, editCart;
	setColor(11,0);
	cout<<"\n\n\nDo you want to edit your cart? [ Add on | Remove item ]\n(N) No\n(Y) Yes"<<endl;
    
	while(true)
	{   
	  setColor(9,0);
      cout<<"\nEnter [N/Y] : ";
      cin >> ans5;
    
     if(ans5 == 'N' || ans5 == 'n')
     {
        ProceedToCheckOut(menu, name, wayName, totalprice, timestamp, recordCount, record, quantity); 
        return;
     }
     else if(ans5 == 'Y' || ans5 == 'y')
     {
    	clrSr();
    	cart(totalprice, recordCount, record, wayName, name, menu); 
    	setColor(9,0);
    	cout<<"\n(A) Remove item from cart"<<endl;
    	cout<<"(B) Add on item"<<endl;
    	cout<<"(C) View menu"<<endl;
    	cout<<"(D) Exit edit"<<endl;
    
        while(true)
        {
    	    setColor(11,0);
            cout<<"\nEnter [ A | B | C | D ] : ";
    	    cin >> editCart;

           if(editCart == 'A' || editCart == 'a')
           {
           	 cout<<"Enter the product ID to remove from your cart : ";  
             cin >> removeId;
             if(cin.fail()) 
		     {  handleInputError(); 
		        continue;
             }
             cout<<"Enter the quantity to remove : ";
             cin >> rvqty;
             if(cin.fail()) 
		     {  handleInputError(); 
		        continue;
             } 
             removeOrder(recordCount, record, menu, totalprice, checkQuantity, name, wayName, quantity, timestamp, removeId, rvqty);
           }
           else if(editCart == 'B' || editCart == 'b')
           {
           	 cout<<endl;
           	 view_product(menu);
           	 setColor(11,0);
             cout<<"Enter the product ID to add on : ";    
             cin >> ans;
             if(cin.fail()) 
		     {  handleInputError(); 
		        continue;
             }  
             cout<<"Enter the quantity : ";
             cin >> quantity;
             if(cin.fail()) 
		     {  handleInputError();
			    continue; 
             } 
             addOrder(ans, record, recordCount, menu, totalprice, checkQuantity, ordernum, quantity);
           }
           else if(editCart == 'C' || editCart == 'c')
           {
        	 cout<<endl<<endl;
        	 view_product(menu);
         	 continue;
		   }
           else if(editCart == 'D' || editCart == 'd')
           { 
             setColor(10,0);
             cout<<"\nPress enter to view your updated cart"<<endl;
             cin.ignore();
             cin.get();
             clrSr();
             cart(totalprice, recordCount, record, wayName, name, menu); 
             ProceedToCheckOut(menu, name, wayName, totalprice, timestamp, recordCount, record, quantity); 
             return;
		   }
           else 
           {  setColor(12,0);
              cout<<"\nWrong enter ! Please enter again..."<<endl;
           }
        }
     }
     else
     {  setColor(12, 0);
        cout<<"\nWrong enter ! Please enter again..."<<endl;
     }
    }
    setColor(7,0);
}

void order(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp)  
{   
    setColor(14, 0);
    cout<<"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<"         Hi, "<< name << " You're now in the ordering process!";                //username
    cout<<"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<"\nBefore order, please select your order type^-^"<<endl;
	wayName = asking();
    
	view_product(menu);
	setColor(9,0);  
	cout<< "\n\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"<<endl;     
    cout<< "   Enter the product ID to add an order | Enter (-1) to finish your order | Enter (-2) to exit your order";                                                                   
	cout<< "\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"<<endl;
		   
    int ans, ordernum = 1, recordCount = 0 , checkQuantity = 0, removeId, rvqty;   //recordCount == count the different products that customers buy //checkQuantity == Total amount of item purchased by customers
    double totalprice = 0.0;                                                       //removeId == product id that user want to remove //rvqty == quantity that user want to remove //totalprice == subtotal 
    OrderRecord record[1000];   //Maximum amount for one order is 1000             
	char ans2;                                                                   
    
    while(true) 
	{   
	    setColor(11,0);                                
        cout<< "\n\nEnter [ Product ID | -1 | -2 ] : ";                       
        cin >> ans;
        if (cin.fail()) 
		{
          handleInputError(); 
          continue;
        } 
        //Go back to homepage       
        if(ans == -2)                                                                                                       
		{   clrSr();
		    homepage(menu, name, wayName, quantity, timestamp);
		    return;
        }
        //Finish order
        if(ans == -1)                                                        
		{   
		    if(recordCount == 0)   //If user havent have any order but enter -1 will run this
            { setColor(13,0);
			  cout<<"\nYou need to place an order first"<<endl;
              continue;
            }
            //remove order
            setColor(3,0);
            cout<<"\n\n........................................................................................................"<<endl;
            cout<<"Do you want to remove any order?\n(Y) Yes\n(N) No"<<endl;
            while(true)
            {
              setColor(3,0);
              cout<<"\nEnter [Y/N] : ";
              cin >> ans2;
              if(ans2 == 'Y' || ans2 == 'y')
              {
                cout<<"\nEnter the product ID to remove : ";   
                cin >> removeId;
                if (cin.fail()) 
		        {  handleInputError(); 
		           continue;
                }  
                cout<<"Enter the quantity to remove   : ";
                cin >> rvqty;
                if (cin.fail()) 
		        {  handleInputError(); 
		           continue;
                }  
                removeOrder(recordCount, record, menu, totalprice, checkQuantity, name, wayName, quantity, timestamp, removeId, rvqty);
              }
              else if(ans2 == 'N' || ans2 == 'n' || ans2 == 'Y' || ans2 == 'y')
              { 
                //View cart //Editing the cart  
                setColor(6, 0);
                cout<<"\n\n\n...Good! You have finished your order..."<<endl;
                cout<<"...Press enter to view your cart..."<<endl;
                cin.ignore();
                cin.get();
                clrSr();
                cart(totalprice, recordCount, record, wayName, name, menu);
                editCart(totalprice, recordCount, record, menu, checkQuantity, name, wayName, ans, ordernum, quantity, timestamp, removeId, rvqty);
                return;
               }
              else
              {  setColor(12, 0);
                 cout<<"\nWrong enter ! Please enter again..."<<endl;
              }
            } 
			break; 
        } 
        //normal order  
        int quantity;   //quantity == quantity of an item that the user wants to order
        setColor(11,0);
        cout<<"Quantity: ";
        cin >> quantity;
        if (cin.fail()) 
		{
          handleInputError(); 
          continue;
        } 
        addOrder(ans, record, recordCount, menu, totalprice, checkQuantity, ordernum, quantity);
    }
        setColor(7,0);
}  

// 6.check history
// Class to store complete order history
class OrderHistory 
{   public:
        string orderNo;
        string customer;
        time_t timestamp;
        vector<OrderRecord> items;
        double subtotal;
        double total;
        string wayName;
        string deliveryAddress;
};

    // Function to parse a date string in YYYY-MM-DD format
    time_t parseDateString(const string& dateStr, bool endOfDay) 
    { // Validate basic format (YYYY-MM-DD)
	  if (dateStr.length() != 10 || dateStr[4] != '-' || dateStr[7] != '-')
      {  return 0;
      }

      long year = 0, month = 0, day = 0;
      for (int i = 0; i < 4; ++i) 
	  {  year = year * 10 + (dateStr[i] - '0');
	  }
      for (int i = 5; i < 7; ++i)
	  {  month = month * 10 + (dateStr[i] - '0');
	  }
      for (int i = 8; i < 10; ++i) 
	  {  day = day * 10 + (dateStr[i] - '0');
	  }
    
      if (year < 1900 || month < 1 || month > 12 || day < 1 || day > 31)
      {  return 0; //Invalid date 
   	  }    
        
      struct tm t = {0};
      t.tm_year = int(year - 1900);
      t.tm_mon = int(month - 1);
      t.tm_mday = int(day);

      if (endOfDay) 
	  {   t.tm_hour = 23;
        t.tm_min = 59;
        t.tm_sec = 59;
      } 
	  else 
	  {   t.tm_hour = 0;
        t.tm_min = 0;
        t.tm_sec = 0;
      }

    return mktime(&t);
}
// Ask if user wants to filter by date 
void askDateFilter(time_t& startDate, time_t& endDate) 
{   char filterChoice;
    setColor(3, 0);
    cout << "\nDo you want to filter by date? (Y/N): ";
    cin >> filterChoice;
    cin.ignore();

    startDate = 0;
    endDate = 0;

    if (filterChoice == 'Y' || filterChoice == 'y') 
	{   string dateStr;
        setColor(11, 0);
        cout << "Enter start date (YYYY-MM-DD): ";
        getline(cin, dateStr);
        startDate = parseDateString(dateStr, false);
        setColor(11, 0);
        cout << "Enter end date (YYYY-MM-DD): ";
        getline(cin, dateStr);
        endDate = parseDateString(dateStr, true);
    }
}
//View order history
void check_history(vector<product>& menu, const string& name, string& wayName, int& quantity, const time_t& timestamp)  
{   // Check if user is logged in
    if (!is_logged_in) 
	{   setColor(4, 0);
        cout << "You must be logged in to view order history!\n";
        setColor(1, 0);
        cout << "Press enter to continue...";
        cin.ignore();
        cin.get();
        clrSr();
        return;
    }

    // Open history file
    ifstream historyFile("order_history.txt");
    if (!historyFile.is_open()) 
	{   setColor(12, 0);
        cout << "No order history found.\n";
        setColor(1, 0);
        cout << "Press enter to continue...";
        cin.ignore();
        cin.get();
        clrSr();
        return;
    }

    vector<OrderHistory> orders;
    string line;
    OrderHistory currentOrder;
    bool readingItems = false;
    int itemsToRead = 0;

    // Parse history file
    while (getline(historyFile, line)) 
	{
        if (line.find("OrderNo:") == 0) 
		{   if (!currentOrder.orderNo.empty()) 
			{   orders.push_back(currentOrder);
                currentOrder = OrderHistory();
            }
            currentOrder.orderNo = line.substr(8);
        } 
        else if (line.find("Customer:") == 0) 
		{   string customer = line.substr(9);
            if (customer != current_user && current_user != "admin") 
			{   // Skip orders that don't belong to current user
                currentOrder.orderNo = ""; // Mark to skip
            } 
			else 
			{   currentOrder.customer = customer;
            }
        }
        else if (line.find("Date:") == 0 && !currentOrder.orderNo.empty()) 
		{   currentOrder.timestamp = atol(line.substr(5).c_str()); 
        }
        else if (line.find("Type:") == 0 && !currentOrder.orderNo.empty()) 
		{   currentOrder.wayName = line.substr(5);
        }
        else if (line.find("Address:") == 0 && !currentOrder.orderNo.empty()) 
		{   currentOrder.deliveryAddress = line.substr(8);
        }
        else if (line.find("Subtotal:") == 0 && !currentOrder.orderNo.empty()) 
		{   currentOrder.subtotal = atof(line.substr(9).c_str());  
        }
        else if (line.find("Total:") == 0 && !currentOrder.orderNo.empty()) 
		{   currentOrder.total = atof(line.substr(6).c_str());     
        }
        else if (line.find("Items:") == 0 && !currentOrder.orderNo.empty()) 
		{   itemsToRead = atoi(line.substr(6).c_str());            
            readingItems = true;
        }
        else if (readingItems && itemsToRead > 0 && line != "---END---") 
		{   stringstream ss(line);
            string id_str, name, price_str, qty_str;
            
            getline(ss, id_str, ',');
            getline(ss, name, ',');
            getline(ss, price_str, ',');
            getline(ss, qty_str, ',');
            
            OrderRecord item;
            item.id = atoi(id_str.c_str());                         
            item.name1 = name;
            item.price = atof(price_str.c_str());                    
            item.qty = atoi(qty_str.c_str());                       
            
            currentOrder.items.push_back(item);
            itemsToRead--;
            
            if (itemsToRead == 0) 
			{   readingItems = false;
            }
        }
        else if (line == "---END---" && !currentOrder.orderNo.empty()) 
		{   orders.push_back(currentOrder);
            currentOrder = OrderHistory();
        }
    } //end of loop 

    historyFile.close();

    // Handle no orders found
    if (orders.empty()) 
	{   setColor(13, 0);
        cout << "No order history found for " << current_user << ".\n";
        setColor(1, 0);
        cout << "Press enter to continue...";
        cin.ignore();
        cin.get();
        clrSr();
        return;
    }
    time_t startDate = 0, endDate = 0;
    askDateFilter(startDate, endDate);
    
    // Display order history
    setColor(14, 0);
    cout << "\n=============================================\n";
    setColor(7, 0);
    cout << "           ORDER HISTORY FOR " << current_user << endl;
    setColor(14, 0);
    cout << "=============================================\n\n";
    
    for (int i = 0; i < orders.size(); ++i) 
	{   const OrderHistory& order = orders[i];
	    if (startDate != 0 && endDate != 0) 
		{  if (order.timestamp < startDate || order.timestamp > endDate) 
		   {  continue;
           }
        }
	    if (order.orderNo.empty()) continue;
	    setColor(11, 0);
        cout << "Order No: " << order.orderNo << endl;
        cout << "Date: " << ctime(&order.timestamp);
        cout << "Type: " << order.wayName << endl;
        cout << "Delivery Address: " << order.deliveryAddress << endl;
        cout << "Items:\n";
        
        for (int j = 0; j < order.items.size(); ++j) 
		{   const OrderRecord& item = order.items[j]; 
		    cout << "  " << item.qty << "x " << item.name1 << " (RM" << fixed << setprecision(2) << item.price << ")\n";
        }
        
        cout << "Subtotal: RM" << fixed << setprecision(2) << order.subtotal << endl;
        cout << "Total: RM" << fixed << setprecision(2) << order.total << endl;
        setColor(14, 0);
        cout << "---------------------------------------------\n\n";
         
    }

    setColor(15, 0);
    cout << "Press enter to return to homepage...";
    cin.ignore();
    clrSr();
    homepage(menu, name, wayName, quantity, timestamp);
}

//picture
void pic_thanks()
{
    system("pause");

    char name[50];
    char str[WIDTH + 2];  // One line per read (+\n+\0)

    sprintf(name, "ASCII-1.txt");  // Or use scanf if needed

    FILE* fp = fopen(name, "r");
    if (fp == NULL)
    {
        perror("Error opening file");
        return;
    }

    setColor(15,0); 
    while (fgets(str, sizeof(str), fp) != NULL)
    {
        printf("%s", str);
    }

    fclose(fp);
    system("pause");
}


int main()
{             
    time_t timestamp;               
    vector<product> menu;
    string wayName = "None";
    int quantity = 0;   
    
    string name = login_page(menu, wayName, quantity, timestamp);
    
    return 0;
}


